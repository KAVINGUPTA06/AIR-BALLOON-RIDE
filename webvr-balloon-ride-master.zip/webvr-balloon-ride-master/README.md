# Balloon ride WebVR experience.

![Screenshot](https://14islands.com/images/blog/2017-05-17-interactive-webvr/balloon-experiment.jpg)

Read about how this was created on the 14islands blog: https://14islands.com/blog/2017/05/17/engaging-vr-experiences-on-the-web/

## Live Demo
https://14islands.github.io/webvr-balloon-ride/

## Install

`mkdir build`

`npm i`

## Run

`npm start`
